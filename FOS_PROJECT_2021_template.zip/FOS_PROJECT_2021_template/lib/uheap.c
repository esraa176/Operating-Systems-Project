#include <inc/lib.h>

// malloc()
//	This function use FIRST FIT strategy to allocate space in heap
//  with the given size and return void pointer to the start of the allocated space

//	To do this, we need to switch to the kernel, allocate the required space
//	in Page File then switch back to the user again.
//
//	We can use sys_allocateMem(uint32 virtual_address, uint32 size); which
//		switches to the kernel mode, calls allocateMem(struct Env* e, uint32 virtual_address, uint32 size) in
//		"memory_manager.c", then switch back to the user mode here
//	the allocateMem function is empty, make sure to implement it.

//==================================================================================//
//============================ REQUIRED FUNCTIONS ==================================//
//==================================================================================//
#define mem (USER_HEAP_MAX-USER_HEAP_START)/PAGE_SIZE
struct allocation_info
{
  int numOfPages;
  uint32 start_address;
  //int isRemoved=0;
}info[mem];
int cnt=0; //number of allocated start virtual addresses

int frames[mem]={0};  //array that determines whether a frame is empty or not
                      //if 0->empty   if 1->not empty


struct freeSpaces  // a struct holds the free spaces in the memory to apply best fit
{
  uint32 startAddr;
  int freeSize;
}fSpace[mem];



void* malloc(uint32 size)
{
  //cprintf("malloc \n");
    //TODO: [PROJECT 2021 - [2] User Heap] malloc() [User Side]
    // Write your code here, remove the panic and write your code
    //panic("malloc() is not implemented yet...!!");

    //This function should find the space of the required range
    //using the BEST FIT strategy

    //refer to the project presentation and documentation for details


    size=ROUNDUP(size,PAGE_SIZE);
    uint32 address=USER_HEAP_START;

    int freeCount=0;    //number of free spaces

    int frameIndex;

    while(address<USER_HEAP_MAX)
    {
      frameIndex=(address-USER_HEAP_START)/PAGE_SIZE;
      if (frames[frameIndex]==0)  //el frame da fady
      {
        fSpace[freeCount].startAddr=address;
        fSpace[freeCount].freeSize=PAGE_SIZE;
        address+=PAGE_SIZE;
        int stop=0;
        while(stop!=1 && address<USER_HEAP_MAX)
        {
          frameIndex=(address-USER_HEAP_START)/PAGE_SIZE;
          if (frames[frameIndex]==0)  //el frame da fady
          {
            fSpace[freeCount].freeSize+=PAGE_SIZE;
            address+=PAGE_SIZE;
          }
          else
          {
            stop=1;
          }
        }

        freeCount++;
      }
      address+=PAGE_SIZE;

    }

    int suitableSpaces=0;
    int bestFit=USER_HEAP_MAX-USER_HEAP_START;
    int index;

    for(int i=0;i<freeCount;i++)
    {
      if(size<=fSpace[i].freeSize)
      {
        suitableSpaces++;
        if(fSpace[i].freeSize<=bestFit)
        {
          bestFit=fSpace[i].freeSize;
          index=i;
        }
      }
    }
    if(suitableSpaces==0)
    {
      return NULL;
    }
    sys_allocateMem(fSpace[index].startAddr,(uint32)size);
    info[cnt].start_address=fSpace[index].startAddr;
    info[cnt].numOfPages=(size/PAGE_SIZE);
    cnt++;
    address=fSpace[index].startAddr;
    for(int i=0;i<size/PAGE_SIZE;i++)
    {
      frameIndex=(address-USER_HEAP_START)/PAGE_SIZE;
      frames[frameIndex]=1;
      address+=PAGE_SIZE;
    }

    return (void*)fSpace[index].startAddr;

}

// free():
//	This function frees the allocation of the given virtual_address
//	To do this, we need to switch to the kernel, free the pages AND "EMPTY" PAGE TABLES
//	from page file and main memory then switch back to the user again.
//
//	We can use sys_freeMem(uint32 virtual_address, uint32 size); which
//		switches to the kernel mode, calls freeMem(struct Env* e, uint32 virtual_address, uint32 size) in
//		"memory_manager.c", then switch back to the user mode here
//	the freeMem function is empty, make sure to implement it.


void free(void* virtual_address)
{
  //cprintf("free \n");
  virtual_address=ROUNDDOWN(virtual_address,PAGE_SIZE);
    //TODO: [PROJECT 2021 - [2] User Heap] free() [User Side]
    int i;
    for (i = 0; i < cnt; i++)
        if ((void*) info[i].start_address == virtual_address)
            break;

    int frameIndex = (info[i].start_address - USER_HEAP_START) / PAGE_SIZE;
    int size = info[i].numOfPages * PAGE_SIZE;
    uint32 address = info[i].start_address;

    for (int j = 0; j < info[i].numOfPages; j++)
    {
        frameIndex = (address - USER_HEAP_START) / PAGE_SIZE;
        frames[frameIndex] = 0;
        address += PAGE_SIZE;
    }
    sys_freeMem(info[i].start_address, size);

    info[i].start_address=0;
    info[i].numOfPages=0;
    //you should get the size of the given allocation using its address
    //refer to the project presentation and documentation for details
}

//==================================================================================//
//================================ OTHER FUNCTIONS =================================//
//==================================================================================//

void* smalloc(char *sharedVarName, uint32 size, uint8 isWritable)
{
  panic("this function is not required...!!");
  return 0;
}

void* sget(int32 ownerEnvID, char *sharedVarName)
{
  panic("this function is not required...!!");
  return 0;
}

void sfree(void* virtual_address)
{
  panic("this function is not required...!!");
}

void *realloc(void *virtual_address, uint32 new_size)
{
  panic("this function is not required...!!");
  return 0;
}

void expand(uint32 newSize)
{
  panic("this function is not required...!!");
}
void shrink(uint32 newSize)
{
  uint32 oldSize=info[cnt-1].numOfPages*PAGE_SIZE;
  newSize= ROUNDUP(newSize, PAGE_SIZE);
  uint32 address=info[cnt-1].start_address;
  address+=newSize;
  uint32 deletedSize = oldSize - newSize;

  info[cnt-1].numOfPages = newSize/PAGE_SIZE;

  int frameIndex = (address - USER_HEAP_START) / PAGE_SIZE;
      uint32 addr = address;
      int deletedPages = deletedSize/PAGE_SIZE;

      for (int j = 0; j < deletedPages; j++)
      {
          frameIndex = (addr - USER_HEAP_START) / PAGE_SIZE;
          frames[frameIndex] = 0;
          addr += PAGE_SIZE;
      }


  sys_freeMem(address, deletedSize);

}

void freeHeap(void* virtual_address)
{
  panic("this function is not required...!!");
}
